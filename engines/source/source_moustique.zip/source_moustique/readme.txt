
Moustique

UCI chess engine written in Pascal by Roland Chastain.

Moustique is the assembly of two programs: a standard chess program (searching the best move) and a mate solver.

The mate solver is an adaptation of a program by Valentin Albillo. The main chess program is an adaptation of a program by Jürgen Schlottke.
